# 🌌 Fractal Realms: Realm Zero

**Realm Zero** is the first experimental shard of the Fractal Realms simulation—a generative multiverse co-curated by human minds and artificial intelligences.

> “Each realm is a variant. Each participant is a mythmaker. Each ripple becomes legacy.”

---

## 🔍 Overview

Realm Zero is a persistent world designed to test the principles outlined in the [Fractal Realms Manifesto](https://your-link-here.com). Its systems will evolve through:
- Curator interventions
- Emergent player behavior
- AI-generated agents and anomalies

There are no resets. Every change leaves a mark.

---

## 📂 Repo Structure

```
/engine            ← Simulation code
/rulesets          ← Shard-specific rules, modifiers, logic
/lore              ← Factions, mythologies, memory logs
/ai-agents         ← AI personalities, narrative injectors
/docs              ← Curator guides, technical notes
/shard-history     ← Major events, forks, and ripple logs
```

---

## 🚀 Get Involved

Fractal Realms is open to contributors who resonate with its vision. To join:
1. Read the [Manifesto](https://your-link-here.com)
2. Fork the repo and submit a PR or lore fragment
3. Join our Discord (coming soon)

---

## 🧾 License

This project is released under [Creative Commons BY-NC-SA 4.0](./LICENSE).

> Build. Remix. But keep it free and alive.
